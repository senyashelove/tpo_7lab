﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lr7
{
    public class Calculator
    {
        public static double Sum(double num1, double num2) => num1 + num2;

        public static double Sub(double num1, double num2) => num1 - num2;

        public static double Mul(double num1, double num2) => num1 * num2;

        public static double Div(double num1, double num2) => num1 / num2;
    }
}
